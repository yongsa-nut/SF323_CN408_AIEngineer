# Silent Hill f

## Overview

**Silent Hill f** (Silent Hill ƒ) is a 2025 survival horror game developed by NeoBards Entertainment and published by Konami Digital Entertainment. It represents a new chapter in the iconic Silent Hill franchise, taking place in Japan during the 1960s.

## Release Information

- **Release Date**: September 25, 2025
- **Platforms**: PlayStation 5, Xbox Series X/S, Steam, Epic Games, Microsoft Windows
- **GOG Release**: October 7, 2025 (DRM-free version)
- **Early Access**: Deluxe edition offered early access two days before official release

## Editions and Pricing

### Standard Edition - $69.99
- Base game only

### Deluxe Edition - $79.99
- Base game
- Digital artbook
- Digital mini-soundtrack
- Pink rabbit costume

## Setting and Story

**Location**: Ebisugaoka, a fictional Japanese town based on the real-life town of Kanayama in Gifu Prefecture, Japan

**Time Period**: 1960s Japan

**Protagonist**: Shimizu Hinako, a high school student from Ebisugaoka

**Plot**: Players control Hinako as she explores her hometown after it becomes engulfed in mysterious fog and transforms into a nightmarish realm. The game involves solving puzzles and fighting for survival as the town shifts between realities.

## Development Team

### Developer
**NeoBards Entertainment Ltd.**
- Independent game developer founded in 2017
- Headquarters in Hong Kong
- Studios in Taipei and Suzhou
- Team consists of industry veterans with over 20 years of game development experience

### Publisher
**Konami Digital Entertainment**

### Creative Team

**Writer**: Ryukishi07
- Known for visual novel "Higurashi When They Cry"
- Chosen by Konami for understanding "the essence of Japanese horror"

**Character/Creature Designer**: kera
- Designed both characters and monsters
- Focused on creating monsters that would "infiltrate players' psyches"
- Worked to combine Ryukishi07's vision with her design aesthetic

**Producer**: Motoi Okamoto

**Director**: Al Yang

**Composers**:
- Akira Yamaoka (Fog World)
- Kensuke Inage (Otherworld)

## Reception and Sales

- Sold over **1 million units** in its first day of release
- Became the **fastest-selling game in the Silent Hill series**

## Tags

#gaming #horror #survival-horror #silent-hill #konami #playstation #pc-gaming #2025

# Recursion

## Definition
Recursion is a programming technique where a function calls itself to solve a problem by breaking it down into smaller, simpler versions of the same problem.

## Key Components

1. **Base Case**: The condition that stops the recursion
2. **Recursive Case**: The part where the function calls itself with modified parameters

## Simple Example

```python
def factorial(n):
    # Base case
    if n == 0 or n == 1:
        return 1

    # Recursive case
    return n * factorial(n - 1)

# factorial(5) = 5 * 4 * 3 * 2 * 1 = 120
```

## Common Use Cases

- Tree traversal
- Sorting algorithms (merge sort, quicksort)
- Mathematical calculations (factorial, Fibonacci)
- Backtracking problems
- Divide and conquer algorithms

## Important Considerations

- Always ensure a base case exists to prevent infinite recursion
- Each recursive call should move closer to the base case
- Can be memory-intensive due to call stack usage
- Sometimes iterative solutions are more efficient

## Related Concepts

- [[Fibonacci Sequences]] - A classic example of recursion
- Iteration vs Recursion
- Stack overflow

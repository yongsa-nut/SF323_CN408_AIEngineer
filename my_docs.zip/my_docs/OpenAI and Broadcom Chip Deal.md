# OpenAI and Broadcom Chip Deal

**Announcement Date**: October 13, 2025

## Overview

OpenAI and Broadcom announced a strategic collaboration to jointly develop and deploy 10 gigawatts of custom AI accelerators. This partnership marks OpenAI's first major move into custom chip design and represents a significant shift in AI infrastructure development.

## Deal Structure

- **Design**: OpenAI designs the custom AI accelerators
- **Development & Deployment**: Broadcom develops and deploys the systems
- **Scale**: 10 gigawatts of AI accelerators
- **Technology**: Custom accelerators networked through Broadcom's Ethernet stack

## Timeline

- **Partnership Duration**: 18+ months of collaboration leading to announcement
- **Deployment Start**: Second half of 2026
- **Completion Target**: End of 2029
- **Type**: Multi-year collaboration

## Technology Details

- Custom AI accelerators optimized for inference workloads
- Broadcom Ethernet and connectivity solutions for networking
- Racks incorporating AI accelerators and Broadcom networking solutions
- Systems designed to embed learnings from AI model development directly into hardware
- Deployment across OpenAI facilities and partner data centers

## Market Impact

- Broadcom stock surged 9.88% following the announcement
- Market value increased by over $150 billion
- Deal valued in multi-billion dollar range
- Significant boost for semiconductor industry and AI infrastructure sector

## Strategic Context

### OpenAI's Broader Chip Strategy

This Broadcom partnership is part of OpenAI's larger strategy to secure compute capacity:
- **Nvidia**: Continued GPU partnerships
- **AMD**: Potential 10% stake deal for AI chips (announced October 6, 2025)
- **Oracle**: Massive compute commitments
- **Broadcom**: Custom chip design and deployment

### Key Objectives

- Reduce reliance on third-party chip suppliers
- Optimize performance for specific AI workloads
- Build infrastructure to support artificial general intelligence (AGI) development
- Meet global AI infrastructure demand
- Ensure AI benefits humanity

## Executive Statements

**Sam Altman (OpenAI CEO)**:
> "Partnering with Broadcom is a critical step in building the infrastructure needed to unlock AI's potential"

**Hock Tan (Broadcom CEO)**:
> "Collaboration signifies a pivotal moment in the pursuit of artificial general intelligence"

## Industry Significance

- Represents trend of AI companies developing custom silicon
- Follows similar moves by Google (TPU), Meta, and Amazon (custom chips)
- Demonstrates importance of vertical integration in AI infrastructure
- Highlights competitive pressure to control full AI stack from chips to models

## Tags

#AI #chips #semiconductors #OpenAI #Broadcom #partnerships #infrastructure #AGI

## Related Topics

- [[Web Search APIs Comparison]] - Related AI infrastructure
- Custom silicon in AI industry
- AI compute capacity challenges
- Semiconductor supply chain

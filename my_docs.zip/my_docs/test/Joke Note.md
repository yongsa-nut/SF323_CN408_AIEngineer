# Programming Jokes

## Why do programmers prefer dark mode?

Because light attracts bugs! 🐛

---

## What's a programmer's favorite hangout place?

The Foo Bar! 🍺

---

## How many programmers does it take to change a light bulb?

None. It's a hardware problem! 💡

---

## Why do Java developers wear glasses?

Because they don't C#! 👓

---

## A SQL query walks into a bar...

Walks up to two tables and asks, "Can I JOIN you?" 🍻

---

#humor #programming #jokes

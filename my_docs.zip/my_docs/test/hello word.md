# Hello Word

Why do programmers prefer dark mode?

Because light attracts bugs! 🐛💡

---

*P.S. I'm not a "hello world" program - I'm a "hello word" document. Yes, I know the difference, but I chose to be unique!*

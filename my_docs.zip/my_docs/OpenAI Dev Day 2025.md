# OpenAI Dev Day 2025

## Overview
OpenAI's third annual Dev Day held on **October 6, 2025** at Fort Mason in San Francisco.

**Attendance**: Over 1,500 developers

## Key Announcements

### AgentKit
Toolkit for building and deploying AI agents with:
- **Agent Builder**: Visual canvas for creating and viewing agents
- Versioning for multi-agent workflows
- All-in-one platform for building agents and adding chat capabilities

### Apps in ChatGPT
New platform for developers to build interactive applications directly inside ChatGPT conversations.

**Launch Partners**:
- Booking.com
- Expedia
- Spotify
- Figma
- Coursera
- Zillow
- Canva

### New Models
- **GPT-5 Pro**: Latest language model
- **Sora 2**: New video generation model
- **Smaller voice model**: More affordable voice capabilities
- **Codex**: Now generally available with Slack integration

### Milestones
ChatGPT reached **800 million weekly active users**

### Future Plans
Hardware products in development with designer Jony Ive enlisted to help shape physical form.

---
*Created: 2025-10-08*

	# The Curve Conference 2025

## Overview

The Curve is a premier big-picture AI conference bringing together 250 thinkers, builders, and leaders to discuss where AI is going, how it will impact the world, and what to do about it.

## Event Details

- **Dates**: October 3-5, 2025
- **Location**: Lighthaven campus, Berkeley, CA
- **Format**: 2.5-day invitation-only event
- **Hosts**:
  - Golden Gate Institute for AI
  - Manifund

## Conference Format

The Curve prioritizes meaningful conversations over traditional conference sessions:

- Small group and one-on-one conversations
- Interactive workshops, debates, and fireside chats
- Some sessions under Chatham House rules
- 24-hour venue access
- Attendees encouraged to skip formal sessions for networking
- Thoughtfully designed attendee roster to facilitate connections

## Key Topics & Questions

The conference addresses major AI questions including:

- Does AI pose an existential threat?
- How should we weigh the risks and benefits of open weights?
- When, if ever, should AI be regulated?
- Should AI development be slowed down or accelerated?
- Should AI be handled as an issue of national security?
- When should we expect AGI?

## Attendees

Curated mix of experts from diverse backgrounds:
- Frontier AI lab researchers
- Government and policymakers
- Startup founders
- Journalists
- Academics
- Venture capitalists

## Notable Speakers

- **Yoshua Bengio** - Turing Award Laureate
- **Ted Chiang** - Author
- **Audrey Tang** - Taiwan's Digital Minister
- **Joseph Gordon-Levitt** - Actor/Entrepreneur
- Representatives from OpenAI, Google, Microsoft, and more

## Ticket Pricing

### Standard Pricing
- **Individual**: $450
- **Institutional**: $900
- **Supporter**: $3,000 (includes speaker reception)

### Early Bird Discount
- 33% off until July 4th

### What's Included
- 7 meals throughout the conference
- Snacks and drinks
- Conference materials

## Registration

### Application Deadlines
- **Early bird**: July 4th
- **Regular**: August 22nd
- **Late**: September 5th

### Notes
- Invitees expected to register within two weeks
- Full refunds available (minus 3% processing fee)

## Links

- Official website: [thecurve.goldengateinstitute.org](https://thecurve.goldengateinstitute.org/)
- Alternative URL: [thecurve.is](https://thecurve.is/)

## Tags

#AI #conference #Berkeley #AGI #artificialintelligence #2025

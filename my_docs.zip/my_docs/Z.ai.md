# Z.ai

## Overview

**Z.ai** (formerly Zhipu AI until 2025 rebrand) is a Chinese artificial intelligence company founded in 2019 and based in Beijing, China. Their mission is "Inspiring AGI to Benefit Humanity" with a focus on developing safe and beneficial Artificial General Intelligence.

## Core Products

### Language Models - GLM Series

**GLM-4.6** (Flagship Model)
- Released: September 30, 2025
- Context window: 202.8K tokens
- Designed to unify frontier reasoning, coding, and agentic capabilities
- Supports planning, coding, and agentic tool use
- Fast response generation: 55+ tokens/second

**GLM-4.5**
- Built on "agentic" AI - automatically breaks down tasks into sub-tasks
- Available as chat interface at https://chat.z.ai/

**GLM-4.5V**
- Vision-language multimodal model
- 106B parameters

### Video Generation

**CogVideoX-3**
- Text-to-video generation model

**Ying**
- Debuted: July 2024
- Generates 6-second video clips from text and image prompts
- Processing time: ~30 seconds

### AI Agent Platform

**AutoGLM**
- Released: October 2024
- Voice-controlled AI agent for smartphone task automation
- Can handle complex tasks like ordering items from nearby stores

### Specialized Capabilities

**Model-Native PPT/Poster Creation**
- GLM-4.5 can autonomously design slide decks and posters
- Integrated presentation generation

## API Offerings

### Pricing (2025)

**GLM-4.6 API**
- Input: $0.50 per million tokens ($0.000500 per 1K tokens)
- Output: $1.75 per million tokens ($0.001750 per 1K tokens)

**GLM Coding Plans** (starts at $3/month)
- **Lite Plan**: ~120 prompts per 5 hours
- **Pro Plan**: ~600 prompts per 5 hours
- **Max Plan**: ~2400 prompts per 5 hours

Note: Contact Sales for enterprise pricing

### Features

- API key management
- Rate limit controls
- Payment method options
- Developer documentation at https://docs.z.ai/

## Developer Integration

### Supported Coding Tools

Z.ai's GLM-4.6 integrates with:
- Claude Code
- Roo Code
- Kilo Code
- Cline
- OpenCode
- Crush
- Goose

### Capabilities for Developers

- Natural language programming
- Intelligent code completion
- Code debugging and repair
- Codebase Q&A
- Automated task handling

## Data Privacy

- Infrastructure based in Singapore
- Company policy: "We do not store any of the content you provide or generate"

## Target Audiences

- Developers
- Enterprises
- Students
- Marketers
- Researchers

## Product Categories

- Text Generation
- Vision AI
- Video Generation
- Multimodal AI

## Key Competitive Positioning

Z.ai positions itself as a cost-effective alternative in the Chinese AI market, claiming to be even cheaper to use than DeepSeek while maintaining high performance across reasoning, coding, and agentic tasks.

## Links

- Official Website: https://z.ai/
- Model API: https://z.ai/model-api
- Chat Interface: https://chat.z.ai/
- Developer Docs: https://docs.z.ai/
- Coding Plans: https://z.ai/subscribe

---

*Last Updated: October 2025*

# Web Search APIs Comparison

A comprehensive guide to modern web search APIs for developers and AI applications.

## Quick Comparison Table

| API                      | Free Tier        | Pricing Model       | Key Strength            | Best For                             | Performance                     |
| ------------------------ | ---------------- | ------------------- | ----------------------- | ------------------------------------ | ------------------------------- |
| **Google Custom Search** | 100 queries/day  | $5/1K queries       | Official Google API     | Custom search engines                | Limited to 10K queries/day      |
| **SerpAPI**              | Trial available  | $50-$2,500/mo       | Comprehensive SERP data | Production apps needing reliability  | 99.95% SLA, instant results     |
| **Brave Search**         | 2,000 queries/mo | $3/1K queries       | Privacy-focused, no ads | High-volume apps, AI grounding       | 95% requests < 1 second         |
| **Tavily**               | 1,000 credits/mo | $30/mo (4K credits) | AI agent optimization   | AI agents & LLMs                     | Real-time, curated results      |
| **Exa**                  | $10 free credits | $5/1K answers       | Semantic search         | AI apps needing intent understanding | Real-time, updated every minute |
| **Jina Reader**          | 10M tokens free  | ~$0.02/M tokens     | URL to Markdown         | LLM grounding, content extraction    | 7.9s avg latency                |

---

## Detailed API Information

### Google Custom Search JSON API

**Official Google search API with limitations**

**Links:**
- Website: https://developers.google.com/custom-search/v1/overview
- Pricing: https://developers.google.com/webmaster-tools/pricing
- Console: https://console.cloud.google.com/marketplace/product/google/customsearch.googleapis.com

#### Pricing
- **Free**: 100 queries per day
- **Paid**: $5 per 1,000 queries (maximum 10,000 queries/day)
- **Search Console API**: Free with usage limits

#### Key Features
- Official Google API for programmatic search
- Limited to custom search engines you create
- RESTful API with JSON responses
- Includes web and image search results

#### Limitations
- Not a true SERP API for general Google search
- Requires creating custom search engine configurations
- Daily query cap of 10,000

#### Best Use Cases
- Custom site search implementations
- Small-scale search integrations
- Projects with limited search needs

---

### SerpAPI

**Enterprise-grade SERP scraping service**

**Links:**
- Website: https://serpapi.com/
- Pricing: https://serpapi.com/pricing
- Documentation: https://serpapi.com/search-api
- Enterprise: https://serpapi.com/enterprise

#### Pricing
- **Standard Plans**: $50 - $2,500/month
  - $50/mo: 5,000 searches with 1,000 searches/hour guaranteed
  - Only successful searches counted
- **Enterprise**: $3,750/month + usage
  - On-demand: $7.50/1K searches ($15 with Ludicrous Speed, $30 with Max)
  - Reserved: $2.75/1K searches ($5.50 with Ludicrous Speed, $11 with Max)

#### Key Features
- Real-time Google search results
- Automatic proxy handling and CAPTCHA solving
- Parses rich structured data (Maps, Local, Stories, Shopping, Knowledge Graph)
- 99.95% SLA guarantee across all plans
- Full browser emulation to mimic human behavior
- Credits for downtime (up to 100% of monthly price)

#### Support
- Email, phone, 24/7 live chat
- Knowledge base and FAQs
- Responsive customer support

#### Best Use Cases
- Production applications requiring high reliability
- SEO and marketing tools
- Large-scale data extraction
- Enterprise applications with SLA requirements

---

### Brave Search API

**Privacy-focused search with massive index**

**Links:**
- Website: https://brave.com/search/api/
- Documentation: https://brave.com/search/api/guides/what-sets-brave-search-api-apart/
- Dashboard: https://api-dashboard.search.brave.com/
- AI Grounding: https://brave.com/blog/ai-grounding/

#### Pricing
- **Free**: 2,000 queries/month
- **Standard**: $3 per 1,000 queries (CPM)
- **AI Grounding**: $4/1K web searches + $5/million tokens
- Options for data storage and LLM training rights

#### Key Features
- Index of 30+ billion pages
- 100M+ page updates daily
- No ads in API results
- Search Goggles for custom result ranking
- Web, image, video, and news search
- Rich responses (sports scores, calculations, stock widgets)
- Up to 5 contextual snippets per search
- Suggest and spellcheck functionality

#### Performance
- Handles 50M+ searches per day
- 95% of requests returned in < 1 second
- Powers top 10 AI LLMs

#### Best Use Cases
- High-volume applications
- AI/LLM search grounding
- Privacy-conscious applications
- Cost-effective search at scale

---

### Tavily

**Search API built specifically for AI agents**

**Links:**
- Website: https://www.tavily.com/
- Documentation: https://docs.tavily.com/
- Pricing: https://docs.tavily.com/documentation/api-credits
- GitHub: https://github.com/tavily-ai

#### Pricing
- **Researcher (Free)**: 1,000 API credits/month
- **Project**: $30/month - 4,000 credits, higher rate limits
- **Add-on**: $100 one-time - 8,000 credits (no expiration)
- **Enterprise**: Custom pricing and features

#### Key Features
- AI-optimized search engine for LLMs
- Aggregated and curated results from single API call
- Intelligent query suggestions and answers
- Automated follow-up queries for deeper knowledge
- Customizable search depths
- Domain management and HTML content control
- Multiple APIs: Search, Extract, Map, and Crawl
- Integration with LangChain and LlamaIndex
- Python library and simple REST API

#### Best Use Cases
- AI agents and autonomous systems
- LLM-powered applications
- RAG (Retrieval-Augmented Generation) pipelines
- Applications requiring trusted, factual results

---

### Exa

**AI-powered semantic search engine**

**Links:**
- Website: https://exa.ai/
- API Documentation: https://docs.exa.ai/
- Pricing: https://exa.ai/pricing
- Websets: https://websets.exa.ai/

#### Pricing
- **Free**: $10 in credits to start
- **API**: $5 per 1,000 answers (pay-per-use)
- **Websets**: $449/month
  - 100,000 credits/month
  - 1,000 results per Webset
  - 10 team seats
  - 50 enrichments per Webset
- **Enterprise**: Custom pricing, SLAs, MSAs

#### Key Features
- Semantic search using neural embeddings
- Understands query intent beyond keywords
- Real-time data retrieval with live crawling
- Index updated every minute
- Powerful filters (date, category, domain)
- 1-1,000s of results per query
- LLM-powered answers
- Websets for people and company data enrichment

#### APIs
- **Search**: Semantic web search
- **Content Crawling**: Real-time web data extraction
- **Websets**: Find and enrich data about people/companies

#### Best Use Cases
- AI applications requiring semantic understanding
- Real-time news and trend tracking
- Company and people research
- Applications needing intent-based search

---

### Jina Reader

**Free URL-to-Markdown converter for LLM grounding**

**Links:**
- Reader API: https://jina.ai/reader/
- Website: https://jina.ai/

#### Pricing
- **Free Tier**: 10 million tokens for new users (shared across all Jina AI services)
- **After Free Tier**: ~$0.02 per million tokens
- **API Key Optional**: Can use without API key but with lower rate limits
- **Rate Limits**:
  - Without API key: 20 requests per minute (rate-limited by IP)
  - With free API key: 200 requests per minute
  - With API key: 500 requests per minute
  - Premium API key: 5,000 requests per minute

#### Key Features
- Converts any URL to clean, LLM-friendly Markdown
- Two modes of operation:
  - **Direct URL**: `https://r.jina.ai/YOUR_URL` - Converts single URL to Markdown
  - **Search Mode**: `https://s.jina.ai/?q=YOUR_QUERY` - Returns top 5 search results with content
- Returns clean text without ads, navigation, or boilerplate
- Perfect for grounding LLMs with web content
- Works with any URL (articles, documentation, blogs, etc.)
- Optional API key for higher rate limits
- Simple prepend-and-go interface
- Average latency: 7.9 seconds
- Token-based pricing after free allocation

#### How to Use
```bash
# Convert a single URL (no API key)
https://r.jina.ai/https://example.com/article

# Search and get top 5 results with content
https://s.jina.ai/?q=web search APIs

# With API key for higher rate limits (add as header)
curl -H "Authorization: Bearer YOUR_API_KEY" https://r.jina.ai/https://example.com/article
```

#### Best Use Cases
- LLM grounding with real-time web content
- Converting web articles to Markdown for processing
- Quick content extraction without scraping
- AI applications needing clean text from URLs
- Prototyping and development (10M token free tier)
- RAG pipelines requiring web content
- Low to medium volume URL conversion (20-200 requests/minute)

---

## Choosing the Right API

### For General Web Search
- **High volume, cost-effective**: Brave Search API
- **Enterprise reliability**: SerpAPI
- **Official Google search**: Google Custom Search (limited)

### For AI Applications
- **AI agents**: Tavily
- **Semantic search**: Exa
- **LLM grounding**: Brave Search, Tavily, or Jina Reader
- **Content extraction**: Jina Reader (10M tokens free)

### For Specialized Needs
- **Privacy-focused**: Brave Search
- **SERP data extraction**: SerpAPI
- **Real-time news**: Exa
- **URL to Markdown conversion**: Jina Reader (10M tokens free, optional API key)

---

## Integration Considerations

### Rate Limits
- **SerpAPI**: 1,000+ searches/hour on basic plans
- **Brave**: Handles 50M+ searches/day
- **Tavily**: Varies by plan
- **Jina Reader**: 20 RPM (no key), 200 RPM (free key), 500 RPM (paid key)

### SLA & Reliability
- **SerpAPI**: 99.95% SLA with financial credits
- **Brave**: Enterprise-grade infrastructure
- **Exa**: Custom SLAs on Enterprise

### Developer Experience
- **Easiest**: Jina Reader (10M tokens free, optional API key, prepend URL)
- **Best docs**: SerpAPI, Tavily
- **AI frameworks**: Tavily (LangChain, LlamaIndex native)

---

## Tags
#api #search #web-search #ai #llm #development #tools

## Related
- [[API Development]]
- [[AI and Machine Learning]]
- [[Web Scraping]]

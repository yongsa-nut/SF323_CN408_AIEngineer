# Nintendo Switch 2

## Overview
The Nintendo Switch 2 is Nintendo's successor to the original Switch console, officially announced on January 16, 2025 and released on June 5, 2025. It maintains backward compatibility with original Switch games while introducing enhanced hardware and new features.

## Timeline
- **January 16, 2025**: Initial announcement
- **April 2, 2025**: Full specifications revealed via Nintendo Direct
- **June 5, 2025**: Global launch

## Pricing
- **Standard (Japanese-Language)**: ¥49,980 (~$450 USD)
- **Multi-Language System**: ¥69,980
- **Mario Kart World Bundle**: ¥53,980 (~$499.99 USD / £429.99)

## Technical Specifications

### Display & Performance
- **Screen**: 7.9-inch LCD display
- **Resolution**: 1920x1080 (1080p) handheld mode
- **TV Output**: Up to 4K at 120 fps
- **Storage**: 256GB internal
- **Battery Life**: 2-6.5 hours (depending on usage)

### Physical Dimensions
- **Size**: 166mm (H) x 272mm (W) x 13.9mm (D)
- **Weight**: ~534g with Joy-Con 2 controllers attached

### Connectivity
- Two USB-C ports
- Improved wireless capabilities

## Key Features

### Hardware Innovations
- **Magnetic Joy-Con 2 Controllers**: Snap onto the console with magnetic connectors
- **Mouse Functionality**: Each Joy-Con 2 can be used as a mouse
- **Enhanced Processing**: More powerful CPU and GPU for improved performance
- **Improved Audio**: More immersive 3D sound
- **Flexible Stand**: Better viewing angles for tabletop mode

### Software Features
- **GameChat**: Voice and video communication (requires Nintendo Switch Online membership)
- **GameShare**: Digital game lending feature
- **Virtual Game Cards**: Enhanced digital game management
- **Backward Compatibility**: Plays both physical and digital Nintendo Switch games
  - Note: Certain Switch games may not be fully compatible

### Accessibility & Safety
- Enhanced accessibility features
- Parental control options

## Launch Titles
- **Mario Kart World** (Switch 2 exclusive)
- **The Legend of Zelda: The Wind Waker** (GameCube classic)
- Various other Nintendo GameCube classics

## Sales Performance
- **3.5 million units** sold worldwide within the first 4 days
- Fastest-selling Nintendo console in company history

## Launch Regions
- Japan
- North America
- Europe
- Australia
- Asia (excluding Mainland China)

## Experience Events
Nintendo hosted hands-on demo events in major cities prior to launch:
- **North America**: New York, Los Angeles, Dallas, Toronto
- **Europe**: Paris, London, Milan, Berlin, Madrid, Amsterdam
- **Oceania**: Melbourne
- **Asia**: Tokyo, Seoul, Hong Kong, Taipei

## Related Links
- Official Website: https://www.nintendo.com/successor/en-us/
- Corporate Press Release: https://www.nintendo.co.jp/corporate/release/en/2025/250402.html

## Tags
#gaming #nintendo #console #hardware

---
*Research completed: October 14, 2025*
*Sources: Official Nintendo press releases and announcements*
# Fibonacci Sequences

The Fibonacci sequence is a series of numbers where each number is the sum of the two preceding ones, typically starting with 0 and 1.

## Definition

The sequence begins: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144...

Mathematically, it can be defined as:
- F(0) = 0
- F(1) = 1
- F(n) = F(n-1) + F(n-2) for n > 1

## Properties

- **Golden Ratio**: As the sequence progresses, the ratio of consecutive Fibonacci numbers approaches the golden ratio (φ ≈ 1.618)
- **Binet's Formula**: Direct calculation without recursion: F(n) = (φⁿ - ψⁿ) / √5, where φ = (1+√5)/2 and ψ = (1-√5)/2

## Applications

- **Nature**: Spiral patterns in shells, flower petals, and pine cones
- **Computer Science**: Algorithm analysis, dynamic programming examples
- **Art & Architecture**: Proportions and aesthetic compositions
- **Financial Markets**: Technical analysis and Fibonacci retracements

## Interesting Facts

- Every 3rd number is divisible by 2
- Every 4th number is divisible by 3
- Every 5th number is divisible by 5
- The sequence appears in Pascal's triangle along diagonal lines

## Related Concepts

#mathematics #sequences #golden-ratio #algorithms

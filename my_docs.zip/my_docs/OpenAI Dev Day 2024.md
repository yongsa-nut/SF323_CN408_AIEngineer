# OpenAI Dev Day 2024

## Overview
OpenAI Dev Day 2024 was held across three cities:
- **San Francisco**: October 1, 2024
- **London**: October 30, 2024
- **Singapore**: November 21, 2024

A more intimate event with ~450 developers in attendance.

## Key Announcements

### Realtime API
Public beta for building apps with low-latency, AI-generated voice responses.

### Vision Fine-Tuning
Fine-tuning support for vision models using images.

### Prompt Caching
Added prompt caching capabilities (similar to Claude and Gemini).

### Model Distillation
New model distillation feature announced.

### o1 Updates
Rate limit doubled from 5,000 to 10,000 RPM.

## Event Activities
- Workshops
- Breakout sessions
- Live coding demonstrations

---
*Created: 2025-10-08*
